# Lab 02 - intro to simplex

The goal of this is lab is to:

* fill missing code in the `saport.simplex.solver` class
* model all the assignemnts from the `assignment.pdf` in the corresponding `zadX.py` files

## SAPORT

SAPORT = Student's Attempt to Produce an Operation Research Toolkit

Refer to the `example.py` for a quick overview of the API.